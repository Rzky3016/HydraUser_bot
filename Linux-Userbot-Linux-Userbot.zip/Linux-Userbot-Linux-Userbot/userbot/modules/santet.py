from time import sleep
from userbot import CMD_HELP
from userbot.events import register


@register(outgoing=True, pattern=r'^\.santet(?: |$)(.*)')
async def typewriter(typew):
    typew.pattern_match.group(1)
    await typew.edit("`Saya Telah Mengaktifkan Perintah Santet Online...⚡`")
    sleep(2)
    await typew.edit("`Mencari Nama Orang Ini...🔍`")
    sleep(1)
    await typew.edit("`Santet Online Segera Dilakukan,Hati Hati Nanti Kejang Kejang Badan Lu`")
    sleep(1)
    await typew.edit("0%")
    number = 1
    await typew.edit(str(number) + "%   ▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   █████████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ██████████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▊")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ███████████████▉")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████▎")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████▍")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████▌")
    number = number + 1
    sleep(0.03)
    await typew.edit(str(number) + "%   ████████████████▌")
    sleep(1)
    await typew.edit("`Target Berhasil Tersantet Online,Maap Cuman Bercanda:v`")


CMD_HELP.update({
    'santetonline':
    '⚡CMD⚡`.santet`\
        \nUsage: Santet Online Buat Bercanda Doang:).'
})
