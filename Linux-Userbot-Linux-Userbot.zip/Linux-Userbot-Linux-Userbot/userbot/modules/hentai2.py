from telethon import events
from telethon.errors.rpcerrorlist import YouBlockedUserError
from userbot import bot, CMD_HELP
from userbot.events import register

# Credit @xflicks Linux-Userbot
# KALAU clone jan di hapus Creditnya asu


@register(outgoing=True, pattern=r"^\.nhentai(?: |$)(.*)")
async def _(event):
    if event.fwd_from:
        return
    link = event.pattern_match.group(1)
    chat = "@Nhentaisupportbot"
    await event.edit("```Memproses```")
    async with bot.conversation(chat) as conv:
        try:
            response = conv.wait_event(
                events.NewMessage(
                    incoming=True,
                    from_users=1752558033))
            await bot.send_message(chat, link)
            response = await response
        except YouBlockedUserError:
            await event.reply("```Di mohon buka blokir @Nhentaisupportbot Dan Coba Kembali```")
            return
        if response.text.startswith(
                "**Maaf, saya tidak bisa mendapatkan manga**"):
            await event.edit("```Saya pikir ini bukan tautan yang benar```")
        else:
            await event.delete()
            await bot.send_message(event.chat_id, response.message)

CMD_HELP.update({
    "hentai2":
    "`.nhentai` <link / code> \
\nUsage: Untuk Mencari Hentai Dengan Kode Nuklir\n"})
