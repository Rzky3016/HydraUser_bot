# Linux Userbot
![Linux-Userbot Logo](https://telegra.ph/file/a347ed9a0b3ae6db7b24c.jpg)



<h3 align="center">Userbot Yang Digunakan Untuk Bersenang-Senang Di Telegram</h3>
<p align="center">&nbsp;</p>

### Repo Linux Userbot
Repo Yang Dibuat [Feri](https://t.me/xflicks) Dari Berbagai Repo Userbot Github 
String_Session [Tekan](https://replit.com/@ferikunn/String-Sesson-Saya)

## Cara Deploy 👷

```
  > Pertama, dapatkan API_KE & API_HASH di my.telegram.org (wajib)

  > Dapatkan Sesi String pada perintah di bawah ini, jalankan di terminal Anda (wajib)

  > Selanjutnya klik Deploy tombol di bawah ini.

  > Isi bidang wajib di heroku

  > Akhirnya nyalakan aplikasi dan periksa log (pengaturan -> lihat log) nikmati :)
```

## Group Support 🛠

   <a href="https://t.me/masukajaudhh"><img src="https://img.shields.io/badge/Group%20Support%3F-yes-green?&style=flat-square?&logo=telegram" width=220px></a></p>


## <p align="center">DEPLOY Linux-Userbot</p>


<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/ferikunn/Linux-Userbot/tree/Linux-Userbot"> <img src="https://img.shields.io/badge/Deploy%20Ke%20Heroku-magenta?style=flat&logo=heroku" width="210" height="34.45" /></a></p>

<br>
</p>

## Kredit
  Terimakasih untuk 
*   [Apis](https://github.com/apisuserbot) - King-Userbot
*   [Alvin](https://github.com/Zora24/Lord-Userbot) - Lord Userbot
*   [RaphielGang](https://github.com/RaphielGang) - Telegram-Paperplane
*   [AvinashReddy3108](https://github.com/AvinashReddy3108) - PaperplaneExtended
*   [Mkaraniya](https://github.com/mkaraniya) & [Dev73](https://github.com/Devp73) - OpenUserBot
*   [Mr.Miss](https://github.com/keselekpermen69) - UserButt
*   [adekmaulana](https://github.com/adekmaulana) - ProjectBish
*   [MoveAngel](https://github.com/MoveAngel) - One4uBot
*   [AidilAryanto](https://github.com/aidilaryanto) - ProjectDils 
*   [Alfianandaa](https://github.com/alfianandaa/ProjectAlf) - ProjectAlf
*   [AnggaR69s](https://github.com/GengKapak/DCLXVI) - DCLXVI
*   [kandnub](https://github.com/kandnub) - TG-UserBot
*   [༺αиυвιѕ༻](https://github.com/Dark-Princ3) - X-tra-Telegram
*   [Sahyam2019](https://github.com/sahyam2019/oub-remix) - oub-remix
*   [TeamUserge](https://github.com/UsergeTeam/Userge) - Userge
*   Dan Lainnya



